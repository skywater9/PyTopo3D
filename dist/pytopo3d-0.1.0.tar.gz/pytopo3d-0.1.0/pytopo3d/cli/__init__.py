"""
Command-line interface utilities for the 3D topology optimization package.
""" 