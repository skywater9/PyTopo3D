"""
Preprocessing modules for topology optimization data.
""" 