"""
Utility functions for 3D topology optimization.
""" 