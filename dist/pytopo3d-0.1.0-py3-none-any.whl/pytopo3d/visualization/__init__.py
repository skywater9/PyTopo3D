"""
Visualization utilities for 3D topology optimization.
""" 